./objects/adc_temp_prj.o: ..\..\system\proj\ADC_TEMP_SENS\ADC_Temp_prj.c \
  ..\..\system\utils\sysdelay.h ..\..\system\board\board_led.h \
  ..\..\system\board\board_adc.h ..\..\system\cmsis\stm32f0xx.h \
  ..\..\system\cmsis\core_cm0.h ..\..\system\cmsis\system_stm32f0xx.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_adc.h \
  ..\..\system\proj\ADC_TEMP_SENS\ADC_Temp_prj.h
