./objects/image.o: ..\..\system\modules\Images\Image.c
