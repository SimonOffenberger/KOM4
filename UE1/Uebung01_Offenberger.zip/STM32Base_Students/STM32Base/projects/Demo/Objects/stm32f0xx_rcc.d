./objects/stm32f0xx_rcc.o: ..\..\system\stm32f0-stdperiph\stm32f0xx_rcc.c \
  stm32f0xx_conf.h ..\..\system\stm32f0-stdperiph\stm32f0xx_adc.h \
  ..\..\system\cmsis\stm32f0xx.h ..\..\system\cmsis\core_cm0.h \
  ..\..\system\cmsis\system_stm32f0xx.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_dma.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_exti.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_gpio.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_i2c.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_rcc.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_syscfg.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_tim.h
