./objects/rgb_timer.o: ..\..\system\board\rgb_timer.c \
  ..\..\system\board\rgb_timer.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_tim.h \
  ..\..\system\cmsis\stm32f0xx.h ..\..\system\cmsis\core_cm0.h \
  ..\..\system\cmsis\system_stm32f0xx.h
