./objects/monochromeimage.o: \
  ..\..\system\modules\Images\MonochromeImage.c
