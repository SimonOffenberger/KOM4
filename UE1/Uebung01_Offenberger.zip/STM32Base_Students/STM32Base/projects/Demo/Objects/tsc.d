./objects/tsc.o: ..\..\system\modules\TSC\tsc.c \
  ..\..\system\modules\TSC\tsc.h ..\..\system\modules\GPIO\Gpio.h \
  C:\Users\Simon\AppData\Local\Arm\Packs\Keil\STM32F0xx_DFP\2.1.1\Drivers\CMSIS\Device\ST\STM32F0xx\Include\stm32f072xb.h \
  ..\..\system\cmsis\core_cm0.h \
  C:\Users\Simon\AppData\Local\Arm\Packs\Keil\STM32F0xx_DFP\2.1.1\Drivers\CMSIS\Device\ST\STM32F0xx\Include\system_stm32f0xx.h
