./objects/board_mcp_temp.o: ..\..\system\board\board_MCP_temp.c \
  ..\..\system\board\board_MCP_temp.h ..\..\system\board\i2c.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_i2c.h \
  ..\..\system\cmsis\stm32f0xx.h ..\..\system\cmsis\core_cm0.h \
  ..\..\system\cmsis\system_stm32f0xx.h
