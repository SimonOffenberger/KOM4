./objects/main.o: main.c stm32f0xx_conf.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_adc.h \
  ..\..\system\cmsis\stm32f0xx.h ..\..\system\cmsis\core_cm0.h \
  ..\..\system\cmsis\system_stm32f0xx.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_dma.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_exti.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_gpio.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_i2c.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_rcc.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_syscfg.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_tim.h \
  ..\..\system\utils\sysdelay.h ..\..\system\proj\3Bit\ CNT\3bit_cnt.h \
  ..\..\system\proj\Alarm\alarm.h ..\..\system\proj\LEDTimer\LedTimer.h \
  ..\..\system\proj\INT\Interrupt_Proj.h \
  ..\..\system\proj\UART_VCOM\Uart_Vcom.h \
  ..\..\system\proj\UART_DMA\Uart_DMA.h \
  ..\..\system\proj\ADC_TEMP_SENS\ADC_Temp_prj.h \
  ..\..\system\proj\I2C_Temp\i2c_temp.h
