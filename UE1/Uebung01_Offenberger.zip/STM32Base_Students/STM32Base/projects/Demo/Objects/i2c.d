./objects/i2c.o: ..\..\system\board\i2c.c \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_gpio.h \
  ..\..\system\cmsis\stm32f0xx.h ..\..\system\cmsis\core_cm0.h \
  ..\..\system\cmsis\system_stm32f0xx.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_rcc.h \
  ..\..\system\board\i2c.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_i2c.h \
  ..\..\system\utils\sysdelay.h
