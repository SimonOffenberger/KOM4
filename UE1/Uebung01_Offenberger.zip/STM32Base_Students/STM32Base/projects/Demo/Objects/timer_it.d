./objects/timer_it.o: ..\..\system\board\timer_it.c \
  ..\..\system\board\timer_it.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_tim.h \
  ..\..\system\cmsis\stm32f0xx.h ..\..\system\cmsis\core_cm0.h \
  ..\..\system\cmsis\system_stm32f0xx.h ..\..\system\board\board_led.h
