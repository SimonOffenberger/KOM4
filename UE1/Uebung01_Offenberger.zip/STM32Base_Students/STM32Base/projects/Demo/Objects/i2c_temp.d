./objects/i2c_temp.o: ..\..\system\proj\I2C_Temp\i2c_temp.c \
  ..\..\system\board\board_led.h ..\..\system\utils\sysdelay.h \
  ..\..\system\proj\I2C_Temp\i2c_temp.h \
  ..\..\system\board\board_MCP_temp.h ..\..\system\board\i2c.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_i2c.h \
  ..\..\system\cmsis\stm32f0xx.h ..\..\system\cmsis\core_cm0.h \
  ..\..\system\cmsis\system_stm32f0xx.h ..\..\system\modules\Lcd\Lcd.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_gpio.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_exti.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_syscfg.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_rcc.h
