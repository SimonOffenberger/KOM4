./objects/board_adc.o: ..\..\system\board\board_adc.c \
  ..\..\system\board\board_adc.h ..\..\system\cmsis\stm32f0xx.h \
  ..\..\system\cmsis\core_cm0.h ..\..\system\cmsis\system_stm32f0xx.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_adc.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_rcc.h
