./objects/3bit_cnt.o: ..\..\system\proj\3Bit\ CNT\3bit_cnt.c \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_gpio.h \
  ..\..\system\cmsis\stm32f0xx.h ..\..\system\cmsis\core_cm0.h \
  ..\..\system\cmsis\system_stm32f0xx.h ..\..\system\board\board_led.h \
  ..\..\system\board\board_button.h \
  ..\..\system\proj\3Bit\ CNT\3bit_cnt.h ..\..\system\utils\sysdelay.h
