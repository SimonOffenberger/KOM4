./objects/interrupt_proj.o: ..\..\system\proj\INT\Interrupt_Proj.c \
  ..\..\system\board\board_led.h ..\..\system\utils\sysdelay.h \
  ..\..\system\cmsis\stm32f0xx.h ..\..\system\cmsis\core_cm0.h \
  ..\..\system\cmsis\system_stm32f0xx.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_gpio.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_exti.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_syscfg.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_rcc.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_tim.h
