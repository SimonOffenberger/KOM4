./objects/uart_vcom.o: ..\..\system\proj\UART_VCOM\Uart_Vcom.c \
  ..\..\system\board\board_uart.h ..\..\system\board\board_led.h \
  ..\..\system\board\board_button.h \
  ..\..\system\proj\UART_VCOM\Uart_Vcom.h ..\..\system\utils\sysdelay.h
