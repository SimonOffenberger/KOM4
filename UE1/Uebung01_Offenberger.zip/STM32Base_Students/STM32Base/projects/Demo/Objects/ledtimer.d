./objects/ledtimer.o: ..\..\system\proj\LEDTimer\LedTimer.c \
  ..\..\system\board\board_led.h ..\..\system\board\board_button.h \
  ..\..\system\proj\LEDTimer\LedTimer.h ..\..\system\utils\sysdelay.h \
  ..\..\system\board\rgb_timer.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_tim.h \
  ..\..\system\cmsis\stm32f0xx.h ..\..\system\cmsis\core_cm0.h \
  ..\..\system\cmsis\system_stm32f0xx.h
