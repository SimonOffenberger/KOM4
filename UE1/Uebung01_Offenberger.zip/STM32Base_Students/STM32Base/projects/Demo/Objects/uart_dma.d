./objects/uart_dma.o: ..\..\system\proj\UART_DMA\Uart_DMA.c \
  ..\..\system\board\board_uart_dma.h ..\..\system\board\board_led.h \
  ..\..\system\proj\UART_DMA\Uart_DMA.h ..\..\system\utils\sysdelay.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_dma.h \
  ..\..\system\cmsis\stm32f0xx.h ..\..\system\cmsis\core_cm0.h \
  ..\..\system\cmsis\system_stm32f0xx.h
