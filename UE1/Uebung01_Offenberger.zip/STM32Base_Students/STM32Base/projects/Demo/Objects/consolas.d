./objects/consolas.o: ..\..\system\modules\Fonts\Consolas.c
