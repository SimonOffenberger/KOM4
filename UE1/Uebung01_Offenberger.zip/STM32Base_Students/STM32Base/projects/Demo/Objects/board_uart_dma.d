./objects/board_uart_dma.o: ..\..\system\board\board_uart_dma.c \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_gpio.h \
  ..\..\system\cmsis\stm32f0xx.h ..\..\system\cmsis\core_cm0.h \
  ..\..\system\cmsis\system_stm32f0xx.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_usart.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_rcc.h \
  ..\..\system\stm32f0-stdperiph\stm32f0xx_dma.h \
  ..\..\system\board\board_uart_dma.h
